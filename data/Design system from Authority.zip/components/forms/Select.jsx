import React from 'react';

export function Select({ label, options = [], value, onChange, disabled }) {
  const [focused, setFocused] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' }}>
      {label && (
        <span style={{ fontSize: 'var(--text-sm)', fontWeight: 500, color: 'var(--ink-700)' }}>{label}</span>
      )}
      <select
        value={value}
        onChange={onChange}
        disabled={disabled}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--text-base)',
          fontWeight: 400,
          color: disabled ? 'var(--ink-300)' : 'var(--ink-900)',
          background: disabled ? 'var(--paper-dim)' : 'var(--white)',
          border: '1px solid',
          borderColor: focused ? 'var(--gold-primary)' : 'var(--line)',
          boxShadow: focused ? 'var(--ring)' : 'none',
          borderRadius: 'var(--radius-md)',
          padding: '11px 14px',
          outline: 'none',
          width: '100%',
          boxSizing: 'border-box',
        }}
      >
        {options.map((o) => (
          <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
        ))}
      </select>
    </label>
  );
}
