Native-backed labeled dropdown, styled to match Input.

```jsx
<Select label="Business model" options={['Coaching', 'Cohort', 'Self-paced']} />
```
