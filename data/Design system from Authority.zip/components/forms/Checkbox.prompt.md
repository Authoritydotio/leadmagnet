Custom checkbox — gold fill with white checkmark when checked.

```jsx
<Checkbox label="I've read the terms" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} />
```
