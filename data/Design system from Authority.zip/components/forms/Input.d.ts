import React from 'react';

export interface InputProps {
  label?: string;
  placeholder?: string;
  type?: string;
  error?: string;
  disabled?: boolean;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

/**
 * @startingPoint section="Forms" subtitle="Labeled text field with error state" viewport="700x160"
 */
export declare function Input(props: InputProps): JSX.Element;
