import React from 'react';

export interface CheckboxProps {
  label?: string;
  checked?: boolean;
  onChange?: (e: { target: { checked: boolean } }) => void;
  disabled?: boolean;
}

export declare function Checkbox(props: CheckboxProps): JSX.Element;
