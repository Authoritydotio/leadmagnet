import React from 'react';

export interface RadioProps {
  label?: string;
  checked?: boolean;
  onChange?: (e: { target: { checked: boolean } }) => void;
  disabled?: boolean;
  name?: string;
}

export declare function Radio(props: RadioProps): JSX.Element;
