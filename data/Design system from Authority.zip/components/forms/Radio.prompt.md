Custom radio button — gold ring when selected.

```jsx
<Radio name="plan" label="Annual" checked={plan === 'annual'} onChange={() => setPlan('annual')} />
```
