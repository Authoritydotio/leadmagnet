Labeled single-line text field. Gold focus ring, red border + message on error.

```jsx
<Input label="Email address" placeholder="you@company.com" />
```
