import React from 'react';

const fieldBase = {
  fontFamily: 'var(--font-sans)',
  fontSize: 'var(--text-base)',
  fontWeight: 400,
  color: 'var(--ink-900)',
  background: 'var(--white)',
  border: '1px solid var(--line)',
  borderRadius: 'var(--radius-md)',
  padding: '11px 14px',
  outline: 'none',
  transition: 'border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)',
  width: '100%',
  boxSizing: 'border-box',
};

export function Input({ label, placeholder, type = 'text', error, disabled, value, onChange }) {
  const [focused, setFocused] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' }}>
      {label && (
        <span style={{ fontSize: 'var(--text-sm)', fontWeight: 500, color: 'var(--ink-700)' }}>{label}</span>
      )}
      <input
        type={type}
        placeholder={placeholder}
        disabled={disabled}
        value={value}
        onChange={onChange}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          ...fieldBase,
          borderColor: error ? 'var(--danger)' : focused ? 'var(--gold-primary)' : 'var(--line)',
          boxShadow: focused ? 'var(--ring)' : 'none',
          background: disabled ? 'var(--paper-dim)' : 'var(--white)',
          color: disabled ? 'var(--ink-300)' : 'var(--ink-900)',
        }}
      />
      {error && <span style={{ fontSize: 'var(--text-xs)', color: 'var(--danger)' }}>{error}</span>}
    </label>
  );
}
