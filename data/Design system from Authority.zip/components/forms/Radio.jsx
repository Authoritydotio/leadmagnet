import React from 'react';

export function Radio({ label, checked, onChange, disabled, name }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-sans)', cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.6 : 1 }}>
      <span
        onClick={() => !disabled && onChange && onChange({ target: { checked: true } })}
        style={{
          width: 18,
          height: 18,
          borderRadius: '50%',
          border: checked ? '5px solid var(--gold-primary)' : '1px solid var(--line)',
          background: 'var(--white)',
          flexShrink: 0,
          boxSizing: 'border-box',
          transition: 'border var(--duration-fast) var(--ease-standard)',
        }}
      />
      {label && <span style={{ fontSize: 'var(--text-sm)', fontWeight: 400, color: 'var(--ink-900)' }}>{label}</span>}
    </label>
  );
}
