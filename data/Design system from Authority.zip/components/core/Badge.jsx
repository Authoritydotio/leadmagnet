import React from 'react';

/** Pill-shaped status/label chip. Uses gold fill for neutral emphasis, or semantic tones. */
export function Badge({ children, tone = 'gold' }) {
  const tones = {
    gold: { background: 'var(--gold-fill-light)', color: 'var(--gold-text)' },
    dark: { background: 'var(--dark-accent)', color: 'var(--white)' },
    success: { background: 'var(--success-tint, var(--color-success-tint))', color: 'var(--success)' },
    danger: { background: 'var(--color-danger-tint)', color: 'var(--danger)' },
    neutral: { background: 'var(--ink-100)', color: 'var(--ink-700)' },
  };
  const t = tones[tone] || tones.gold;
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '4px 12px',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-sans)',
        fontWeight: 500,
        fontSize: 'var(--text-xs)',
        letterSpacing: 'var(--tracking-wide)',
        ...t,
      }}
    >
      {children}
    </span>
  );
}
