Generic surface container — white background, hairline border, soft shadow, 16px radius.

```jsx
<Card>
  <h3>Coaching at Scale</h3>
  <p>...</p>
</Card>
```

Set `padded={false}` when the card contains its own full-bleed content (e.g. an image header).
