import React from 'react';

const sizeStyles = {
  sm: { padding: '8px 14px', fontSize: 'var(--text-sm)', gap: 6 },
  md: { padding: '11px 20px', fontSize: 'var(--text-base)', gap: 8 },
  lg: { padding: '14px 26px', fontSize: 'var(--text-lg)', gap: 8 },
};

const base = {
  fontFamily: 'var(--font-sans)',
  fontWeight: 500,
  border: 'none',
  borderRadius: 'var(--radius-pill)',
  cursor: 'pointer',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  transition: 'background var(--duration-base) var(--ease-standard), color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)',
  lineHeight: 1,
};

function variantStyle(variant, disabled) {
  if (disabled) {
    switch (variant) {
      case 'secondary':
        return { background: 'transparent', color: 'var(--ink-300)', border: '1px solid var(--line)' };
      case 'ghost':
        return { background: 'transparent', color: 'var(--ink-300)' };
      default:
        return { background: 'var(--ink-100)', color: 'var(--ink-300)' };
    }
  }
  switch (variant) {
    case 'secondary':
      return { background: 'var(--white)', color: 'var(--ink-900)', border: '1px solid var(--line)' };
    case 'ghost':
      return { background: 'transparent', color: 'var(--ink-900)' };
    case 'danger':
      return { background: 'var(--danger)', color: 'var(--white)' };
    default:
      return { background: 'var(--gold-primary)', color: 'var(--white)' };
  }
}

export function Button({ children, variant = 'primary', size = 'md', disabled, onClick, type = 'button' }) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const vs = variantStyle(variant, disabled);
  let bg = vs.background;
  if (!disabled && hover) {
    if (variant === 'secondary') bg = 'var(--paper-dim)';
    else if (variant === 'ghost') bg = 'var(--gold-fill-light)';
    else if (variant === 'danger') bg = '#8A2525';
    else bg = 'var(--color-accent-hover)';
  }
  if (!disabled && active) {
    if (variant === 'primary') bg = 'var(--color-accent-active)';
  }
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{
        ...base,
        ...sizeStyles[size],
        ...vs,
        background: bg,
        transform: active && !disabled ? 'scale(0.98)' : 'scale(1)',
        opacity: disabled ? 0.7 : 1,
      }}
    >
      {children}
    </button>
  );
}
