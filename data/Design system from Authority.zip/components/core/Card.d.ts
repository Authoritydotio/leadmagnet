import React from 'react';

export interface CardProps {
  children: React.ReactNode;
  /** @default true */
  padded?: boolean;
  style?: React.CSSProperties;
}

export declare function Card(props: CardProps): JSX.Element;
