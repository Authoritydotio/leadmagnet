import React from 'react';

export interface ButtonProps {
  children: React.ReactNode;
  /** @default 'primary' */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** @default 'md' */
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  onClick?: () => void;
  type?: 'button' | 'submit';
}

/**
 * @startingPoint section="Core" subtitle="Primary CTA button" viewport="700x160"
 */
export declare function Button(props: ButtonProps): JSX.Element;
