Small pill label for status, category, or emphasis. Not clickable.

```jsx
<Badge tone="gold">New</Badge>
```

Tones: `gold` (default, light gold fill), `dark`, `success`, `danger`, `neutral`.
