Primary call-to-action button. Use for the single most important action on a screen or section.

```jsx
<Button variant="primary" size="md" onClick={handleSubmit}>
  Get the Business Plan
</Button>
```

Variants: `primary` (solid gold, default), `secondary` (white + hairline border), `ghost` (text-only, gold-tint hover), `danger` (destructive actions, red).
Sizes: `sm`, `md`, `lg`. All fully rounded (pill radius) per brand.
