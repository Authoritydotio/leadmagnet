import React from 'react';

/** Surface container: white card, hairline border, soft shadow, generous radius. */
export function Card({ children, padded = true, style }) {
  return (
    <div
      style={{
        background: 'var(--white)',
        border: '1px solid var(--line)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-sm)',
        padding: padded ? 'var(--space-6)' : 0,
        fontFamily: 'var(--font-sans)',
        ...style,
      }}
    >
      {children}
    </div>
  );
}
