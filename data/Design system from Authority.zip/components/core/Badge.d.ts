import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  /** @default 'gold' */
  tone?: 'gold' | 'dark' | 'success' | 'danger' | 'neutral';
}

export declare function Badge(props: BadgeProps): JSX.Element;
