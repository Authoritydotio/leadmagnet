# Authority DS

An original design system for a coaching / online-education-business brand, in the spirit of authority.io — built from user-supplied brand guidelines and a provided logo file, not scraped from the live site. (No access to authority.io's actual codebase or Figma was available or used; visual choices below come from the brand spec given directly by the user.)

## Context
- **Category**: coaching-at-scale / expert-education businesses — landing pages, webinar funnels, course platform UI, and sales decks.
- **Audience**: experienced professionals and operators, not beginners.
- **Sources provided**: `uploads/logo.svg` (wordmark, used as-is in `assets/logo.svg`) and a written brand-guidelines spec (colors, type, voice) supplied directly by the user in chat.

## Index
- `styles.css` — root stylesheet, imports all tokens.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`.
- `components/core/` — Button, Badge, Card.
- `components/forms/` — Input, Select, Checkbox, Radio.
- `slides/` — 5 deck slide layouts: Title, Agenda, Credibility Stats, Quote, Call to Action.
- `guidelines/` — foundation specimen cards (colors, type, spacing, radii/shadow, logo).
- `assets/logo.svg` — brand wordmark (as supplied by user).

## Content fundamentals
- **Voice**: grounded, not flashy. Honest, not harsh. Smart, not complicated.
- **Person**: direct address ("you've built real expertise," "you're stuck in a model that has a ceiling") — speaks to the reader's own experience, not abstractions.
- **Claims**: backed by specific numbers ($211M+ in client revenue, 4,000+ experts served) rather than vague superlatives.
- **Casing**: sentence case for body copy and headlines; short uppercase eyebrow labels with wide letter-spacing for section kickers only.
- **Emoji**: not used.
- Copy leans on transformation-over-information framing: sell outcomes, not information.

## Visual foundations
- **Type**: single family (Inter), weights 400 and 500 only — hierarchy is built with size and color, never boldness beyond medium.
- **Color**: off-white/white paper surfaces, near-black (#1a1a1a) as the dark anchor for high-contrast sections (title slides, credibility stats), and a single primary gold (#B4882A) accent used sparingly for CTAs, stats, and emphasis. Light gold fill (#FAEEDA) is reserved for pills, callouts, gated-content banners, and focus rings — never as a large background. Semantic red/green exist only for danger/success states, not decoration.
- **Backgrounds**: flat color only — no gradients, no photography treated as texture, no patterns.
- **Corners**: buttons and pills are fully rounded (999px); cards and inputs use a moderate 10–16px radius.
- **Shadows**: soft, low-elevation, tinted toward the dark accent (never pure black) — used only on white cards to lift them off paper.
- **Borders**: 1px hairline in a warm light neutral (`--line`), used on cards/inputs instead of heavy shadows for most separation.
- **Motion**: fast, subtle — 120–200ms ease-standard transitions on hover/press only (background/color/shadow). No bounces, no page-load animation.
- **Hover/press**: buttons darken slightly on hover and scale to 0.98 on press; ghost buttons pick up a light gold tint on hover instead of a border.
- **Transparency/blur**: not used — surfaces are always opaque.
- **Imagery**: none supplied; none invented. Where a design needs a photo, use a plain labeled placeholder and ask the user for the real asset.

## Iconography
- No icon set was supplied. The one checkmark glyph (Checkbox) is drawn as a minimal inline SVG stroke to match line weight elsewhere; no icon font or library is bundled. If the brand has a preferred icon set (e.g. Lucide/Heroicons), tell me and I'll wire it in.

## Intentional additions
Only a standard baseline set was built (no source component library was provided): Button, Badge, Card, Input, Select, Checkbox, Radio. Badge was added because course/coaching cards commonly need a status or category chip — not in the original ask, but a natural companion to Card.

## Fonts
Inter is loaded from Google Fonts (`tokens/typography.css`) since no font files were supplied and the brand spec explicitly named Inter. No substitution needed.
